	<?php

	/**
	 * 
	 */
	class ClassName
	{
		/*
		 * $needs = [
		 *  'material_id' => need|int
		 * ];
		 *
		*/
		public static function reduceStock()
		{
			$stock = PurchaseToMaterial::getPurchases(array_keys($needs));
			GoodsSkuToMaterial::reduce($stock, $needs);
			
			return true;
		}
	}