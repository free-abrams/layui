<?php

namespace App\Models;

use App\Admin\Handers\MaterialHander;
use Carbon\Carbon;
use Encore\Admin\Facades\Admin;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class GoodsSkuToMaterial extends BaseModel
{
	protected $fillable = [
		'goods_sku_id',
		'material_id',
		'number'
	];
	
	public function material()
	{
		return $this->belongsTo(Material::class);
	}
		
	// 减少库存 生成记录
	public static function reduce($stock = [], $needs = [])
	{
		foreach ($needs as $k => $v) {
			$reduceStock = MaterialHander::deduction_stock($stock[$k], $v);
			
			foreach ($reduceStock as $key => $value) {
				// 减少库存
				static $pToMaterial = [];
				$pToMaterial[] = [
					'id' => $value['id'],
					'stock' => $value['stock'],
					'sell' => $value['sell'],
					'status' => $value['status']
				];
				// 生成消耗记录
				static $record = [];
				$record[] = [
					'store_id' => Admin::user()->store_id,
					'purchase_to_material_id' => $value['id'],
					'material_id' => $k,
					'number' => $v,
					'description' => '生成sku',
					'style' => 2,
					'type' => 2,
					'created_at' => Carbon::now(),
					'updated_at' => Carbon::now()
				];
			}
		}
		// 批量更新
		PurchaseToMaterial::updateBatch('purchase_to_materials', $pToMaterial);
		// 批量插入
		DB::table('record_materials')->insert($record);
	}
}
